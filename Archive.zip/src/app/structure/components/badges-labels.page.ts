import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './badges-labels.html'
})

export class ComponentsBadgesLabels {}

