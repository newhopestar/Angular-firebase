import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './modal.html'
})

export class ComponentsModal {}

