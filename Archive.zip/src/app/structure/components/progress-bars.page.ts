import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './progress-bars.html'
})

export class ComponentsProgressBars {}

