import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './steps.html'
})

export class ComponentsSteps {}

