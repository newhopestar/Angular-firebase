import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './dropdowns.html'
})

export class FormsDropdowns {}

