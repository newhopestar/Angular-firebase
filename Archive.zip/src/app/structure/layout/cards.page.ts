import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './cards.html'
})

export class LayoutCards {}
