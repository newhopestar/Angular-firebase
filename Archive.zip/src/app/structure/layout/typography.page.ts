import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './typography.html'
})

export class LayoutTypography {}

