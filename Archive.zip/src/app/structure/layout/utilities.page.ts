import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './utilities.html'
})

export class LayoutUtilities {}

