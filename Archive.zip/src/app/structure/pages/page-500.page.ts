import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './page-500.html'
})

export class PagesPage500 {}

