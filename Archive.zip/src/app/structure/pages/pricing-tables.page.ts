import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './pricing-tables.html'
})

export class PagesPricingTables {}

